from PreprocessPipeline import Pipeline
from ExtractFeature import WritingStyle
import pandas as pd
from csv import writer
import os
from os import path

def execute_preprocessing(input_path):
    """This method uses nltk for preprocessing"""
    preprocess = PreprocessFiles()
    file_list = preprocess.fetch_file_list(input_path)
    file_text_dict = preprocess.get_file_content(file_list)
    token_sentences, tokens, token_without_sw = preprocess.tokenize_sentence_word(file_text_dict)
    # ner tagging
    ner_tagged_words = preprocess.ner_tagging(tokens)
    # token_sentences, tokens, token_without_sw
    return ner_tagged_words


def execute_preprocess_pipeline(input_path):
    """This method uses spacy for preprocessing"""
    pipeline = Pipeline()
    processed_tokens,sentences,doc_dict = pipeline.preprocess_text(html_path=input_path)
    return processed_tokens,sentences,doc_dict


def fetch_ws_features(processed_tokens,sentences,doc_dict):
    ws_obj = WritingStyle()
    pronoun_dict = ws_obj.extract_m_f_count(processed_tokens,sentences,doc_dict)
    print(pronoun_dict)
    return pronoun_dict


def fetch_sentiment_dict(sentences_dict):
    ws_obj = WritingStyle();
    sentiment_dict = ws_obj.calculate_sentiment(sentences_dict)
    # sentences_dict['pg426']
    print(sentiment_dict)
    return sentiment_dict

def write_to_csv(feature_dict,senti_dict):


    csv_file = "D:\\Edu\\dump\\ext_features.csv"
    header = ['book_id','male_pn_count','female_pn_count','locative_pn_count','comma_count',
              'period_count','colon_count','semi_colon_count','hyphen_count',
              'exclam_count','conjunction_count','interjection_count','pos_sent','neg_sent','neut_sent',
              'plot_complexity', 'genre']

    master_frame = pd.read_csv("D:\\Edu\\dump\\master996.csv", sep=";", encoding='unicode_escape')

    if path.exists(csv_file):
         os.remove(csv_file)
    try:
        with open(csv_file, 'w+') as write_obj:
            # Create a writer object from csv module
            csv_writer = writer(write_obj, lineterminator='\r')
            csv_writer.writerow(header)
            # Add contents of list as last row in the csv file

            for (book_id, list_val), (b_id, sent_list) in zip(feature_dict.items(), senti_dict.items()):
                # rows = []
                temp = [book_id]
                temp.extend(list_val)
                temp.extend(sent_list)
                try:
                    temp.append(master_frame.loc[master_frame['book_id'] == book_id]['guten_genre'].values[0])
                except:
                    temp.append("NONE")
                # rows.append(temp)
                csv_writer.writerow(temp)

    except IOError:
        print("I/O error in writing the feature csv file")


def main():
    input_path = "D:\\Edu\\dump\\"
    # execute_preprocessing(input_path)

    processed_tokens, sentences,doc_dict = execute_preprocess_pipeline(input_path)
    feature_dict = fetch_ws_features(processed_tokens,sentences,doc_dict)
    sentiment_dict = fetch_sentiment_dict(sentences)
    write_to_csv(feature_dict, sentiment_dict)
   


if __name__ == "__main__":
    main()
