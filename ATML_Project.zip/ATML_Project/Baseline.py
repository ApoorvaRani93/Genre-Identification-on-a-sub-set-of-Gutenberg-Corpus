import pandas as pd 
from os import listdir
from os.path import join
import codecs
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
import nltk
nltk.download('punkt')
nltk.download('stopwords') 
nltk.download('wordnet')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
stoplist = set(stopwords.words('english')) 


# Helper functions to perform basic pre-processing tasks
def tokenize_word_text(text): 
    tokens = nltk.word_tokenize(text) 
    tokens = [token.strip() for token in tokens if token.isalpha()] 
    return tokens

# Remove stop words from the book content
def remove_stop_words(tokens_list):
  tokens_without_sw = [word for word in tokens_list if not word in stoplist]
  return tokens_without_sw

# Applying lemmatization on book content
def get_lemmatized_words(tokens_list):
  lemmatizer = WordNetLemmatizer()
  lemmatized_tokens = [lemmatizer.lemmatize(token) for token in tokens_list]
  return lemmatized_tokens







master_frame = pd.read_csv("/content/master996 (1).csv", sep=";", encoding='unicode_escape')
path=r'/content/baseLine' 
htmlFiles = [join(path, f) for f in listdir(path) ]
print(len(htmlFiles))
textList = []
genereList = []
for i in range (len(htmlFiles)):
  print(i)
  if("ipynb" in (htmlFiles[i])):
    i = i+1
    continue

  bookId = htmlFiles[i].strip().split("/")[-1][:-13]
  try:
    bookGenre = master_frame.loc[master_frame['book_id'] == bookId]['guten_genre'].values[0] 
  except:
    bookGenre = "None"
  genereList.append(bookGenre)
  file = codecs.open(htmlFiles[i], "r", "utf-8")
  soup = BeautifulSoup(file.read(), 'html.parser')
  text = ''.join([t for t in soup.find_all(text=True) if t.parent.name == 'p'])
  text = tokenize_word_text(text)
  text = remove_stop_words(text)
  text = get_lemmatized_words(text)
  text = " ".join(text)
  textList.append(text)

df = pd.DataFrame(textList) 
df = df[df.columns[0]]
vectorizer = TfidfVectorizer()
print("hi 1")
X = vectorizer.fit_transform(df)
print("hi 2")
newdf = pd.DataFrame(X.toarray(), columns = vectorizer.get_feature_names()) 
newdf['Genere'] = genereList 
print(newdf.head())
newdf.to_csv("tfIdf_csvFile.csv")
#newdf.to_csv("/content/drive/My Drive/Colab Notebooks/tfIdf_csvFile.csv")