import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from pandas import DataFrame, Series
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE, ADASYN, RandomOverSampler
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import f1_score, make_scorer,accuracy_score

# Evaluation
from sklearn.metrics import fbeta_score, make_scorer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import cross_val_score

# Hyper param tuning
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline

# Classification Models
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.utils import class_weight
from sklearn.svm import SVC

filePath = r'tfIdf_csvFile-2.csv'

df = pd.read_csv(filePath, engine='python')
df.set_index('book_id', drop=True, inplace=True)

# REMOVING BOOKS WITH NO GENRES
df = df[df['genre']!='NONE']

X = df.values[:, 1:-1]
y= df.values[:,-1]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, stratify=y)

randomovSm = RandomOverSampler()
X_train, y_train = randomovSm.fit_sample(X_train,y_train)


clf_2=RandomForestClassifier()
grid_params = { 
    'n_estimators': [200, 700],
    'max_features': ['auto', 'sqrt', 'log2']
}


f1_scorer = make_scorer(fbeta_score, beta=1, average='micro')
grid = GridSearchCV(clf_2, grid_params, cv=10, scoring=f1_scorer, return_train_score=True)
grid.fit(X_train, y_train)

df = pd.DataFrame(grid.cv_results_)[['mean_test_score', 'std_test_score', 'params']]
print(df['mean_test_score'].max())
df

y_pred=grid.predict(X_test)

labels=['Allegories', 'Christmas Stories', 'Detective and Mystery',
       'Ghost and Horror', 'Humorous and Wit and Satire', 'Literary',
       'Love and Romance', 'Sea and Adventure', 'Western Stories']
df2=((pd.DataFrame(confusion_matrix(y_test,y_pred,labels=labels),index=[format(x) for x in labels], 
    columns=[format(x) for x in labels])))



df2.to_csv('test.csv')

#np.unique(y_train)

print(accuracy_score(y_test,grid.predict(X_test))*100)